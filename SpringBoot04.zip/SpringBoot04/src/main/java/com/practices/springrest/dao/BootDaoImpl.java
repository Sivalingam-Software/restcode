package com.practices.springrest.dao;

import java.io.Serializable;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.practices.springrest.exception.MyException;
import com.practices.springrest.model.Employee;

@Repository
public class BootDaoImpl implements BootDao{

	
//	@Autowired
//	SessionFactory sessionFactory;
	
	
//	@Autowired
//	HibernateTemplate hibernateTemplate;
	
	@PersistenceContext
	EntityManager entityManager;
	
	public String saveObject(Object object) throws MyException{
		Serializable serializable="";
//		entityManager.persist(object);
		entityManager.merge(object);
//		try(Session session=sessionFactory.openSession()){
//			serializable=session.save(object);
//			session.beginTransaction().commit();
////			hibernateTemplate.
//		}catch (Exception exception) {
//		throw new MyException(exception.getMessage());
//		}
		return serializable.toString();
	}

	@Override
	public Employee getEmployeeInfo(Integer empId) throws MyException {	
		return entityManager.find(Employee.class, empId);
	}

	@Override
	public String updateEmployee(Employee employee) throws MyException {
//		entityManager.getLockMode(employee);
//		System.out.println("Lock mode::"+entityManager.getLockMode(employee).name());
		Employee emp=getEmployeeInfo(employee.getEmpId());
		emp.setMobNumber(45545455L);
		entityManager.merge(emp);
		System.out.println("FlushMode::"+entityManager.getFlushMode().name());
//		entityManager.getTransaction().commit();
		entityManager.flush();
//		entityManager.remove(entity);
//		entityManager.createQuery("").setParameter("", "").setFirstResult(0).setMaxResults(2).getResultList();
//		entityManager.createQuery("").getSingleResult();
//		entityManager.create
		return null;
	}
}
