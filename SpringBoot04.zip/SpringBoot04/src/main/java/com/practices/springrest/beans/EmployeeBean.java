package com.practices.springrest.beans;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;

public class EmployeeBean {

	public EmployeeBean() {}
	private Integer empId;
	@NotNull(message = "Please provide Employee NAme")
	@NotEmpty(message = "Please provide Employee name")
	private String empName;
	private String department;
	
	private Department department2;
//	@Size(max = 20, min = 3, message = "{user.number.invalid}")
//	@Range(min=5, max=20, message="Invalid miob numbe")
//	@Min(value=4,message="Minimum 4 digi gfgg")
	private Long mobNumber;
	
	public EmployeeBean(Integer empId, String empName, String department, Long mobNumber) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.department = department;
		this.mobNumber = mobNumber;
	}
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Long getMobNumber() {
		return mobNumber;
	}
	public void setMobNumber(Long mobNumber) {
		this.mobNumber = mobNumber;
	}
	public Department getDepartment2() {
		return department2;
	}
	public void setDepartment2(Department department2) {
		this.department2 = department2;
	}
	
}
