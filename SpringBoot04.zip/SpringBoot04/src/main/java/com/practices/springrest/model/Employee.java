package com.practices.springrest.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Entity
@Table(name = "Employee1001")
@Cache(usage=CacheConcurrencyStrategy.TRANSACTIONAL)
//@Check(constraints = "COL_A IS NULL OR (COL_B IS NOT NULL and COL_C IS NOT NULL)")
public class Employee {
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer empId;
	private String empName;
	@Column(columnDefinition = "VARCHAR(60) CHECK (department IN ('SOFTWARE', 'PREAUTH', 'CLAIM'))")
	private String department;
	private Long mobNumber;
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Long getMobNumber() {
		return mobNumber;
	}
	public void setMobNumber(Long mobNumber) {
		this.mobNumber = mobNumber;
	}
	
	
}
