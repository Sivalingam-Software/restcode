package com.practices.springrest.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.practices.springrest.beans.EmployeeBean;
import com.practices.springrest.dao.BootDao;
import com.practices.springrest.exception.MyException;
import com.practices.springrest.model.Employee;

@Service
public class BootServicesImpl implements BootServices{

	@Autowired
	BootDao bootDao;

	@Override
	@Transactional
	public String saveObject(Object employeeBean) throws MyException {
		
		return bootDao.saveObject(employeeBean);
	}

	@Override
	public Employee getEmployeeInfo(Integer empId) throws MyException {
		return bootDao.getEmployeeInfo(empId);
	}

	@Override
	@Transactional
	public String updateEmployee(Employee employee) throws MyException {
		
		return bootDao.updateEmployee(employee);
	}
}
