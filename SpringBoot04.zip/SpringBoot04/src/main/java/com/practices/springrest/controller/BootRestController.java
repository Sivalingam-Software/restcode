package com.practices.springrest.controller;

import java.util.HashMap;
import java.util.Map;

import javax.validation.ConstraintViolationException;
import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.practices.springrest.beans.EmployeeBean;
import com.practices.springrest.exception.MyException;
import com.practices.springrest.model.Employee;
import com.practices.springrest.services.BootServices;

@RestController
public class BootRestController {

	@Autowired
	BootServices bootServices;
	
	@RequestMapping("/")
	public String welComePage() {
		System.out.println("This is welcome page");
		return "Welcome to rest api world";
	}
	@RequestMapping("/employee/{empId}")
	public EmployeeBean getEmployee(@PathParam("empId") Integer empId) {
		EmployeeBean employeeBean=new EmployeeBean();
		employeeBean.setEmpId(empId);
		employeeBean.setDepartment("tyuyyuyy Engineer");
//		employeeBean.setEmpName("RAM");
		employeeBean.setMobNumber(3223L);
		return employeeBean;
	}
	
	
	@PostMapping(value="/saveEmployee", produces= {"application/json"}, consumes= {"application/json"})
	public ResponseEntity<Object> saveEmployee(@Valid @RequestBody EmployeeBean employeeBean){
		String serialId=null;
//		try {
			Employee employee=new Employee();
			System.out.println("employeeBean department::"+employeeBean.getDepartment2().getDeptId());
			BeanUtils.copyProperties(employeeBean,employee);
			try {
			 serialId=bootServices.saveObject(employee);
			 System.out.println("serialId::"+serialId);
			}catch(Exception e) {
				System.out.println("exception::"+e);
			}
			if(serialId!=null) {
				MyException myException=new MyException();
				myException.setErrorCode(HttpStatus.OK.toString());
				myException.setErrorMessage("Successfully Added Emplyee, You refence is::"+serialId);
				return ResponseEntity.status(HttpStatus.OK).body(myException);
			}
			else {
				MyException myException=new MyException();
				myException.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
				myException.setErrorMessage(new MyException().toString());
//				return ResponseEntity.status(HttpStatus.OK).body(myException);
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(myException);
			}
			
//		}catch (Exception e) {
//			MyException myException=new MyException();
//			myException.setErrorCode(HttpStatus.INTERNAL_SERVER_ERROR.toString());
//			myException.setErrorMessage(new MyException().toString());
////			return ResponseEntity.status(HttpStatus.OK).body(myException);
//			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(myException);
//		}
	}
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();

		ex.getBindingResult().getFieldErrors().forEach(error -> 
			errors.put(error.getField(), error.getDefaultMessage()));
		
		return errors;
	}
	
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(ConstraintViolationException.class)
	public Map<String, String> handleConstraintViolation(ConstraintViolationException ex) {
		Map<String, String> errors = new HashMap<>();
		
		ex.getConstraintViolations().forEach(cv -> {
			errors.put("message", cv.getMessage());
			errors.put("path", (cv.getPropertyPath()).toString());
		});	

		return errors;
	}
	
	@GetMapping("/getEmployeeInfo/{empId}")
	public Employee getEmployeeInfo(@PathVariable("empId") String empId) {
		Employee employee=new Employee();
		try {
			System.out.println("empIdempId::"+empId);
			employee=bootServices.getEmployeeInfo(Integer.parseInt(empId));
			System.out.println("employee::"+employee.getEmpName());
		}catch (Exception e) {

		}
		return employee;
	}
	
	@PostMapping("/updateEmployee")
	public String updateEmployee(@RequestBody EmployeeBean employeeBean) {
		String update=null;
		try {
			Employee employee=new Employee();
			System.out.println("employeeBean department::"+employeeBean.getDepartment());
			BeanUtils.copyProperties(employeeBean,employee);
			update=bootServices.updateEmployee(employee);
		}catch (Exception e) {
	System.out.println("update exceptionm::"+e);
		}
		
		return update;
	}
}
