package com.practices.springrest.services;

import com.practices.springrest.exception.MyException;
import com.practices.springrest.model.Employee;

public interface BootServices {

	String saveObject(Object employeeBean) throws MyException;

	Employee getEmployeeInfo(Integer empId) throws MyException;

	String updateEmployee(Employee employee) throws MyException;

}
