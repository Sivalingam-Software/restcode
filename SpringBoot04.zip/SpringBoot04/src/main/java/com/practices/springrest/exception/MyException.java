package com.practices.springrest.exception;

import java.sql.SQLException;

public class MyException extends Exception{

	public MyException() {}
	private String errorMessage;
	private String errorCode;
	
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public MyException(String errorMessage) {
		this.errorMessage=errorMessage;
	}
	public MyException(String errorMessage, String errorCode) {
		this.errorMessage=errorMessage;
		this.errorCode=errorCode;
	}
	
	@Override
	public String toString() {
		return (errorCode+" "+errorMessage).trim();
	}
	

	
}
