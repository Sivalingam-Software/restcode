package com.practices.springrest.exception;

public class ResponseDTO {

}
